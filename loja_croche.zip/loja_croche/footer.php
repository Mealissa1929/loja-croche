<footer class="bg-cor-secundaria text-white">

    <div class="container py-5">

      <div class="row">

        <div class="col-md-3">

          <h5 class="text-primary">Atendimento</h5>

          <ul>
            <li>(11) 999999999</li>
            <li>email@gmail.com</li>
            <li>Horário de atendimento:</li>

            <li>Segunda a sexta das 09h00 as 17h00</li>
          </ul>
        </div>

        <div class="col-md-3">

          <h5 class="text-primary">Acesso rápido</h5>

          <ul>
            <li>Minha conta </li>
            <li>Meus pedidos</li>
            <li>Rastrear meus pedidos</li>
            <li>Troca devolução</li>
          </ul>
        </div>

        <div class="col-md-3">

          <h5 class="text-primary">Instituicional</h5>

          <ul>
            <li>Sobre a loja</li>
            <li>Política e privacidade</li>
      
          </ul>
        </div>

        <div class="col-md-3 mb-5 mb-md-0">

          <h5 class="text-primary">Mais acessados</h5>

          <ul>
            <li>Cropped rosa</li>
            <li>Camiseta manga comprida</li>
            <li>Camiseta listrada </li>
            <li>Saia Prensada</li>

          </ul>
        </div>

      </div>

    </div>

  </footer>

  <script src="assets/scripts/bootstrap.bundle.min.js"></script>
</body>

</html>