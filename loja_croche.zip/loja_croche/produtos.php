<?php require __DIR__ . "/header.php"; ?>

<main>

<h1>produtos</h1>

</main>


<?php require __DIR__ . "/footer.php"; ?>